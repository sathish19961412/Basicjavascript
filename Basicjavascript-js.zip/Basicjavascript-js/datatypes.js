let firstname="sathish"; //string
let age= 24 ;  //int
let isYoung=true; //Boolean
let lastname;  //undefined
let trophy=null;