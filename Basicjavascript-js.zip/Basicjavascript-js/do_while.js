i=11;

do{
    if(i%2!==0)
    {
        console.log("Odd Numbers",+i);
    }
    i++;
}while(i<=5);