//Condition ? 'Value1' : 'value2'
let age =  19;
let type = age < 18 ? "Child Ticket" : "Adult Ticket";
console.log(type);
