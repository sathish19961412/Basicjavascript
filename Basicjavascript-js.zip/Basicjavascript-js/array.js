let color=["red","white","black"]
/*{}-object
  []-array
*/
color[3]=45;
console.log(color);
console.log(color.length);
