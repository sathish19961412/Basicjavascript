/*
  Gloabal To Decalre the Javascript
*/
   console.log("Failure is a success to First Step");
/*
  It is debugging to the Console
  Chorme is used to V8 engine
 */
