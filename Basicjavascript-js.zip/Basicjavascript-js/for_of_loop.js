let colors=["red","green","yellow"];
for (let color of colors){
    console.log("Color:"+ color);
}