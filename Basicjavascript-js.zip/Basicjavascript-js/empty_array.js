//Empty an javascript Array
//ex1:
let numbers=[1,2,3,4]
console.log(numbers)

let num=numbers=[]
console.log(num)

//ex2:
let len=numbers.length=0;
console.log(len)

//ex3:
let splice=numbers.splice(0,numbers.length)
console.log(splice)


