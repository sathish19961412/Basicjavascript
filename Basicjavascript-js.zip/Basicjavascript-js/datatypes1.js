/*
->1.primitive types
1.String 2.Integer 3.Boolean 4.Undefined 5.null

->2.Reference Types
1.Object 2.Function 3.Array
*/

let firstname="sathish"; //String
let age=24; //int
let isYoung=true; //Boolean
let lastname=undefined;//undefined
let trophy=null;  //null