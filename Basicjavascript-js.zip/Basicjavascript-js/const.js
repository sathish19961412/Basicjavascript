const name="sathish";
const dob="14-12-1996";
/*
name ="sathish mathew"; //Cannot modify and edit to the const variable values

*/
msg = "Hello my name is" + name + "& I am Bron in" + dob + "I am learning Javascript";

console.log(msg);
