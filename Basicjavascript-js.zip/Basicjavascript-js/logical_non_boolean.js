let usercolor="red";
let defaultcolor="blue";
let currentcolor=usercolor || defaultcolor;
console.log("Selected color:"+currentcolor);