//Comparison Operator

let x=10;
let y=5;
//Strict Equality  Operators(Datatype + Value)
console.log("10"===10); // 10===10

//Lose Equality Operators
console.log(x==10); //5!==5

//Relational Operators

console.log(x<10); //Less Than
console.log(x<=10); //Less than or Equal To
console.log(x>10); //Greater Than
console.log(y=>10); //Greater Than Or Equal TO 

//String Comparsion
console.log('alen' > 'anbu'); //dictory

//Comparison of Different Type
console.log("2"< 5); //1<5

//Boolean True Or False

console.log(true==0);

// 1-True 0-False