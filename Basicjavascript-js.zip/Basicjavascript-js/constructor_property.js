//ex1:
let name="sathish"; //new string()
let 