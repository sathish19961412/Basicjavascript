let number1=10;
let number2=45;
//Arithimatic Operations
console.log(number1+number2);
console.log(number1-number2);
console.log(number1*number2);
console.log(number1/number2);
console.log(number1**number2);

//Increment Operator
console.log(number1++);
console.log(number1);
//Decrement Operator
console.log(number2--);
console.log(number2);