//assignment Operator
let x=12;
// x--; Assginment Operator
// x=x+2; Assginment Operator
x/=5;  //Assignment Operator
console.log(x);