const person={
    name:"sathish",
    age:24,
    sex:'male'
};
for(let key in person)
{
    console.log(key+":",person[key]);
}