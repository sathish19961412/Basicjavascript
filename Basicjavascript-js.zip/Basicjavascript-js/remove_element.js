//Remove Element in the array
const number=[1,2,3,4]

//End
//Push()=>add
//pop()=>remove

let pop1=number.pop()
console.log(number);

let push1=number.push(5,6)
console.log(number);

//start
//unshift=>shift

let shift1=number.shift()
console.log(number);

//middle
//splice
let middle=number.splice(1,1)
console.log(number);