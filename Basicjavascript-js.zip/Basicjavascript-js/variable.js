let name="sathish";
let msg="Hello my name is " + name +"I am learning Javascript";

//alert
alert(msg);

//Logging

console.log(msg);


let num1=4;
let num2=5;

let result=num1+num2;

console.log(result);

/* 
     1.No Keywors in Variable name
     2.Should not start with letter
     3.No Space & No -
     4.It is Case-Sensitive
     5.Use Meaningfull Names
*/