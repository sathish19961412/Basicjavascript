//Add Elements in Arrays
//Ex1:
const numbers=["Apple","Lemon"];
console.log(numbers);

//Ex2:

let updatenum=numbers[2]="Orange";

console.log(updatenum);

//Ex3:
//Push
let pushs=numbers.push("orange","strawberies")
console.log(pushs);

//unshif
let unshifs=numbers.unshift('Gavwa')
console.log(unshifs);

//splice

