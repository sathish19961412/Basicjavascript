//Example1
function greetuser(name){
    //set of statements
    let msg="Hello" +" "+ name + " I'm Learning Javascript";
    console.log(msg);
}
    greetuser("sathish")

//Example2

function greetuser1(firstname,lastname){
    //set of statements
    let msg="Hello" +" "+ firstname +" " + lastname +" "+"I'm Learning Javascript !" ;
    console.log(msg);
}
   greetuser1("sathish","mathew")
   greetuser1("guru","prasanth")