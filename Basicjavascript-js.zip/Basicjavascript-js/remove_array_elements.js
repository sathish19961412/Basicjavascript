//Remove Element in the array

const remove=[1,2,3,4,5]