//For Each

const dailyRoutine=["wakeup","Eat","sleep"];

dailyRoutine.forEach((routine,RoutineIndex)=>{
    console.log(RoutineIndex,routine);
});