i=1;

while(i<=10)
{
    if(i%2 !==0)
    {
        console.log("Resverse Display Odd Number",+i);
    }
    // else if(i%2===0)
    // {
    //     console.log("Resverse Display Even Number",+i);
    // }
    i++;
}