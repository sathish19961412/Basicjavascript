let i=0;
for(;;){
    console.log("this is infinite loop");
}