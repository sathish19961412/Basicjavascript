//Check To Dummies.com To The Used Operator Precedence
//ex:1
let x=2+5*10;
console.log(x);

//ex:2
 let y=(2+5)*10;
 console.log(y);