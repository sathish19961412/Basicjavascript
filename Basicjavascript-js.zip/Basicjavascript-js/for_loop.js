//syntax for loop
/*
for(intialstate;condition;incrementoperator)
{
   console.log("For Loop Synatax");
}
*/

//ex:1
for(i=0;i<=5;i++)
{
    if(i%2 !==0)
    {
       console.log("List of Odd Numbers", + i);
    }
}

//ex:2 
for(j=10;j>=1;j--)
{
   if(j%2 !==0)
   {
      console.log("List Of Reverse Odd Numbers", + j);
   }
}